import { expect } from "chai";
import { shuffle } from "../src/Shuffle.js";

describe("shuffle()", () => {
  it("returns an array with the same items", () => {
    const original = [1, 2, 3, 4, 5];
    const result = shuffle(original);

    expect(result).to.have.members(original);
    expect(result).to.have.lengthOf(original.length);
  });

  it("shuffles the indexes of an array (should change order at least once over multiple runs)", () => {
    const original = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    let changed = false;

    for (let i = 0; i < 20; i += 1) {
      const result = shuffle([...original]);
      const sameOrder = result.every((v, idx) => v === original[idx]);
      if (!sameOrder) {
        changed = true;
        break;
      }
    }

    expect(changed).to.equal(true);
  });
});
