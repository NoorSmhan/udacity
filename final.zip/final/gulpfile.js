import gulp from "gulp";
import shell from "gulp-shell";

// Serves the app via Parcel (also builds and outputs to /dist)
// Run with: npm run gulp
export const parcel = shell.task([
  "npx parcel index.html --dist-dir dist --port 1234",
]);

// Runs Mocha unit tests
// Run with: npm run gulp test
export const test = shell.task(["npx mocha --recursive --timeout 10000"]);

// Runs Cypress E2E tests (requires the Parcel server to already be running)
// Run with: npm run gulp cypress
export const cypress = shell.task(["npx cypress run"]);

gulp.task("parcel", parcel);
gulp.task("test", test);
gulp.task("cypress", cypress);

// Default: build + serve with Parcel
gulp.task("default", gulp.series("parcel"));
