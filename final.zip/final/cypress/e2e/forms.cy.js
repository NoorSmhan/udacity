describe("Forms", () => {
  beforeEach(() => {
    cy.visit("/");
    cy.get('[data-cy="nav-card-sets"]').click();
  });

  describe("Create Set Form", () => {
    it("happy path: creates a new set with valid input", () => {
      // Show the form
      cy.get('[data-cy="toggle_form"]').first().click();

      cy.get('[data-cy="set_form"]').should("be.visible");
      cy.get('[data-cy="titleInput"]').clear().type("My Test Set");
      // Submit Set button is created via createSubmitButton("Submit Set")
      cy.get('[data-cy="submit_set"]').click();

      cy.contains("My Test Set").should("be.visible");
    });

    it("unhappy path: shows error when submitting empty set title", () => {
      cy.get('[data-cy="toggle_form"]').first().click();

      cy.get('[data-cy="set_form"]').should("be.visible");
      cy.get('[data-cy="titleInput"]').clear();
      cy.get('[data-cy="submit_set"]').click();

      cy.get(".error").should("be.visible");
    });
  });

  describe("Add Card Form", () => {
    beforeEach(() => {
      // Open the first existing set (id: 1) to enter the flashcards page
      cy.get('[data-cy="1"]').click();
      // Show the add-card form
      cy.get('[data-cy="toggle_form"]').first().click();
      cy.get('[data-cy="card_form"]').should("be.visible");
    });

    it("happy path: adds a card with valid term and description", () => {
      cy.get('[data-cy="termInput"]').clear().type("Cypress");
      cy.get('[data-cy="descriptionInput"]').clear().type("E2E testing tool");
      // Submit button value is "Add Card"
      cy.get('[data-cy="add_card"]').click();

      cy.contains("Cypress").should("be.visible");
    });

    it("unhappy path: shows error when any input is empty", () => {
      cy.get('[data-cy="termInput"]').clear();
      cy.get('[data-cy="descriptionInput"]').clear().type("Some description");
      cy.get('[data-cy="add_card"]').click();

      cy.get(".error").should("be.visible");
    });
  });
});
