describe("Navigation", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("clicking Card Sets in the menu navigates to the card sets page", () => {
    cy.get('[data-cy="nav-card-sets"]').click();
    cy.get('[data-cy="study-set-header"]').should("be.visible");
  });

  it("clicking About in the menu navigates to the about page", () => {
    cy.get('[data-cy="nav-about"]').click();
    cy.get('[data-cy="about_page"]').should("be.visible");
  });

  it("clicking Home in the menu navigates to the home page", () => {
    cy.get('[data-cy="nav-home"]').click();
    cy.get('[data-cy="home_header"]').should("be.visible");
  });
});
